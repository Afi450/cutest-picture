# Felted Otter & Duckling — make.fun "Make the cutest picture" entry

A felted wool otter hugging a sleepy duckling, 1024x1024. The program is the
simplest allowed entry: it copies the image stored in this repository to
`output/entry.png`. No network, no randomness — two runs are byte-identical.

## Run it

```sh
python3 main.py
```
