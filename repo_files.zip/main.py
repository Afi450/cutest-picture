"""Felted otter & duckling — make.fun "Make the cutest picture" entry.

Copies the image stored in this repository to output/entry.png.
No network, no randomness: two runs produce identical bytes.
"""

import os
import shutil

ROOT = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(ROOT, "entry.jpg")
OUT_DIR = os.path.join(ROOT, "output")


def main() -> None:
    os.makedirs(OUT_DIR, exist_ok=True)
    shutil.copyfile(SRC, os.path.join(OUT_DIR, "entry.png"))


if __name__ == "__main__":
    main()
